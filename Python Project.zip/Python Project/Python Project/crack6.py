import pygame
import random
import sys

# Function to load sentences from Sentences.txt file
def load_sentences(file_path):
    with open(file_path, 'r') as file:
        sentences = file.readlines()
    return [sentence.strip() for sentence in sentences]

# Function to display text on the screen
def display_text(screen, font, text, position, color):
    text_surface = font.render(text, True, color)
    screen.blit(text_surface, position)

# Function to calculate words per minute (WPM)
def calculate_wpm(time_elapsed, typed_text):
    words = len(typed_text.split())
    minutes = time_elapsed / 60
    wpm = words / minutes
    return wpm

# Function to calculate accuracy
def calculate_accuracy(original_text, typed_text):
    correct_chars = sum(1 for c1, c2 in zip(original_text, typed_text) if c1 == c2)
    accuracy = (correct_chars / len(original_text)) * 100
    return accuracy

def main():
    pygame.init()

    # Colors
    white = (255, 255, 255)

    # Load sentences from file
    sentences = load_sentences("C:/Users/Kryptos/Documents/Bullshit/Sentences.txt")

    # Initialize pygame window in fullscreen mode
    pygame.display.init()
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

    # Get screen dimensions
    screen_width, screen_height = pygame.display.get_surface().get_size()

    # Load background image
    background = pygame.image.load("C:/Users/Kryptos/Documents/Bullshit/background.jpg")
    background = pygame.transform.scale(background, (screen_width, screen_height))

    # Load splash screen image
    splash_screen = pygame.image.load("C:/Users/Kryptos/Documents/Bullshit/type-speed-open.png")

    # Load reset button image
    reset_button = pygame.image.load("C:/Users/Kryptos/Documents/Bullshit/icon.png")
    reset_button = pygame.transform.scale(reset_button, (50, 50))  # Resize the button
    reset_button_rect = reset_button.get_rect(topleft=(screen_width - 60, 10))  # Button rect for collision detection

    # Fonts
    font = pygame.font.Font(None, 36)

    # Variables
    clock = pygame.time.Clock()
    typing = False
    typed_text = ""
    start_time = 0
    sentence = random.choice(sentences)
    cumulative_wpm = 0
    total_words = 0
    total_chars = 0

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_RETURN:
                    if not typing:
                        typing = True
                        typed_text = ""
                        start_time = pygame.time.get_ticks()
                elif event.key == pygame.K_BACKSPACE:
                    typed_text = typed_text[:-1]
                elif event.key == pygame.K_LSHIFT:
                    cumulative_wpm = calculate_wpm((pygame.time.get_ticks() - start_time) / 1000, typed_text)
                    accuracy = calculate_accuracy(sentence, typed_text)
                    print("Cumulative WPM:", cumulative_wpm)
                    print("Accuracy:", accuracy)
                else:
                    typed_text += event.unicode
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if reset_button_rect.collidepoint(event.pos):  # Check if the mouse click is on the reset button
                    typing = False
                    typed_text = ""
                    sentence = random.choice(sentences)

        screen.blit(background, (0, 0))

        if not typing:
            screen.blit(splash_screen, (0, 0))
        else:
            display_text(screen, font, sentence, (50, 50), white)
            display_text(screen, font, typed_text, (50, 100), white)

            # Calculate time elapsed
            current_time = pygame.time.get_ticks()
            time_elapsed = (current_time - start_time) / 1000

            # Calculate WPM and accuracy
            if time_elapsed > 0:
                wpm = calculate_wpm(time_elapsed, typed_text)
                accuracy = calculate_accuracy(sentence, typed_text)
                display_text(screen, font, f"WPM: {wpm:.2f}", (50, 150), white)
                display_text(screen, font, f"Accuracy: {accuracy:.2f}%", (50, 200), white)

        # Display reset button
        screen.blit(reset_button, reset_button_rect)

        pygame.display.flip()
        clock.tick(30)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
